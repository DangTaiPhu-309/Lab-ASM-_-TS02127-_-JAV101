package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({"/Bai3","/nv/insert","/nv/update","/nv/delete","/nv/find"})
public class Bai3Controller extends HttpServlet
{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	req.getRequestDispatcher("Bai3.jsp").forward(req, resp);
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String url = req.getRequestURI();
		
		if(url.contains("/nv/insert"))
		{
			resp.getWriter().print("<h1>insert data </h1>");
		}
		else if (url.contains("/nv/update"))
			resp.getWriter().print("<h1>update </h1>");
		else if (url.contains("/nv/delete"))
			resp.getWriter().print("<h1>delete </h1>");
		else if (url.contains("/nv/find"))
			resp.getWriter().print("<h1>find ...</h1>");
		}
}
