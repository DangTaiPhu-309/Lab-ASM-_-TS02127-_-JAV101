package Lab7.poly.servlet;

import Lab7.poly.dao.DepartmentDAO;
import Lab7.poly.dao.DepartmentDAOIpml;
import Lab7.poly.entity.Department;
import org.apache.commons.beanutils.BeanUtils;

// ❗ ĐỔI javax → jakarta
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
@WebServlet({
    "/department/index",
    "/department/edit/*",
    "/department/create",
    "/department/update",
    "/department/delete/*",
    "/department/reset",
    "/department/search"
})
public class DepartmentSevlet extends HttpServlet {

@Override
protected void service(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {

    DepartmentDAO dao = new DepartmentDAOIpml();
    Department form = new Department();

    try {
        BeanUtils.populate(form, req.getParameterMap());
    } catch (Exception e) {}

    String uri = req.getServletPath();      // /department/create
    String extra = req.getPathInfo();       // /001 nếu có

    // ========== EDIT ==========
    if (uri.contains("edit") && extra != null) {
        String id = extra.substring(1);
        form = dao.findById(id);
    }

    // ========== CREATE ==========
    else if (uri.contains("create")) {
        dao.create(form);
        resp.sendRedirect(req.getContextPath() + "/department/index");
        return;
    }

    // ========== UPDATE ==========
    else if (uri.contains("update")) {
        dao.update(form);
        resp.sendRedirect(req.getContextPath() + "/department/index");
        return;
    }

    // ========== DELETE ==========
    else if (uri.contains("delete") && extra != null) {
        String id = extra.substring(1);
        dao.deleteById(id);
        resp.sendRedirect(req.getContextPath() + "/department/index");
        return;
    }

 // ========== SEARCH ==========
    else if (uri.contains("search")) {
        String keyword = req.getParameter("keyword");
        req.setAttribute("list", dao.findByKeyword(keyword));
        req.setAttribute("item", new Department());
        req.getRequestDispatcher("/Department.jsp").forward(req, resp); // FIXED
        return;
    }

    // Mặc định load list
    req.setAttribute("item", form);
    req.setAttribute("list", dao.findAll());
    req.getRequestDispatcher("/Department.jsp").forward(req, resp); // FIXED
}}

