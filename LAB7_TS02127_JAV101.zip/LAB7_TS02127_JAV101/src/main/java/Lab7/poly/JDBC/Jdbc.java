package Lab7.poly.JDBC;

import java.sql.*;

public class Jdbc {

    // ================== CẤU HÌNH DATABASE ===================
    private static final String URL = 
        "jdbc:sqlserver://localhost:1433;databaseName=lab6_java3_csdl;encrypt=false;";
    private static final String USER = "SA";
    private static final String PASS = "123456";

    // ================== NẠP DRIVER ===================
    static {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            System.out.println(">> SQLServer JDBC Driver Loaded!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================== GET CONNECTION ===================
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    // ================== EXECUTE UPDATE ===================
    public static int executeUpdate(String sql, Object... args) {
        try (Connection con = getConnection();
             PreparedStatement ps = createStatement(con, sql, args)) {
            return ps.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException("Lỗi executeUpdate → " + e.getMessage(), e);
        }
    }

    // ================== EXECUTE QUERY ===================
    public static ResultSet executeQuery(String sql, Object... args) {
        try {
            Connection con = getConnection();
            PreparedStatement ps = createStatement(con, sql, args);
            return ps.executeQuery();  // ❗ Không đóng, để DAO đọc ResultSet
        } catch (Exception e) {
            throw new RuntimeException("Lỗi executeQuery → " + e.getMessage(), e);
        }
    }

    // ================== CREATE STATEMENT (PROC + SQL) ===================
    private static PreparedStatement createStatement(Connection con, String sql, Object... args) throws Exception {
        PreparedStatement ps;

        // Hỗ trợ Stored Procedure dạng {call ...}
        if (sql.trim().startsWith("{")) {
            ps = con.prepareCall(sql);
        } else {
            ps = con.prepareStatement(sql);
        }

        // Đổ tham số
        for (int i = 0; i < args.length; i++) {
            ps.setObject(i + 1, args[i]);
        }
        return ps;
    }
}
